            
class ladders{
    //Snake is a class that represents the snake in our game. It has attributes for its length, direction of movement and position on the grid
    constructor (tailLocation){
        this.tailLocation = tailLocation;
        
        


    }
}